<?php 
	class SP {
	    public $root_path = "/home/standar2/public_html/dev/";
	    public $media_path = "/";

	    function include_header($title){
		  	$sp_title = $title;
		  	include("header.php");
		 	}
		
			function include_nav(){
		  	include("nav.php");
		 	}
		
			function include_footer(){
		  	include("footer.php");
		 	}
	}
 ?>