	<div id="footer">
		<div><img src="/img/ScrumMaster.png" width="176" height="50" align="right" /></div>
	</div>
</body>
</html>