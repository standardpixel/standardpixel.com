<div id="navigation">
	<ul>
		<li><a href="/">Home</a></li>
		<li><a href="/EricGelinas-WebInterfaceEngineer.php">Resum&eacute;</a></li>
		<li><a href="http://blog.standardpixel.com">Blog</a></li>
		<!--<li><a href="/contact.php">Contact</a></li>-->
		<li><a href="/status.php">Status</a></li>
	</ul>
</div>