<?php 
	$sp = new SP();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Standard Pixel : <?= $sp_title; ?></title>
	<!-- YAHOO Global Object source file --> 
	<script type="text/javascript" src="http://yui.yahooapis.com/2.3.0/build/yahoo/yahoo-min.js" ></script>
	
		<?php
		echo "<style>";
		
		require($sp->root_path . "css/yui-reset-min.css");

		require($sp->root_path . "css/yui-base-min.css");

		require($sp->root_path . "css/yui-fonts-min.css");

		require($sp->root_path . "css/base.css");
		
		require($sp->root_path . "css/rollbahn.css");
		
		echo "</style>";
		?>
	
</head>

<body>
	<div id="header">
		<div id="logo"></div>
		<h1>StandardPixel.com</h1>
		<h2><?= $sp_title ?></h2>
	</div>